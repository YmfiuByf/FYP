from __future__ import division
from scipy.fftpack import dct

file_path = ''

# 1.sample  2.preemphasis  3.fft
import decimal
import os
import librosa
import numpy as np
import math
import logging
from tqdm import tqdm
import torch


# # default 16000Hz, 25ms<=>400 samples, step=10ms=160 samples, rectangular window
# def framesig(signal, frame_len=400, frame_step=160, winfunc=lambda x: np.ones((x,)) ):
#     slen = len(signal)
#     total_num = (slen-1)//frame_step
#     padsignal = np.concatenate((signal, np.zeros((total_num*frame_step+frame_len-slen,))))
#     win = winfunc(frame_len)
#
#     shape = padsignal.shape[:-1]+(total_num+1 , frame_len)  # [num of signal, num of frame, frame length]
#     strides = (padsignal.strides[0],) + (padsignal.strides[-1]*frame_step,) + (padsignal.strides[-1],)
#     frames = np.lib.stride_tricks.as_strided(padsignal, shape=shape, strides=strides)
#     return frames * win

def framesig(signal, frame_len=400, frame_step=160, winfunc=lambda shape: np.ones(shape) ):
    return frames_sig(signal[None,], frame_len=400, frame_step=160, winfunc=lambda num_frame, frame_len: np.ones((num_frame, frame_len)) )[0]

# this is used for signal array, framesig is for one single signal
def frames_sig(signals, frame_len=400, frame_step=160, winfunc=lambda num_frame, frame_len: np.ones((num_frame, frame_len)) ):
    sp = signals.shape
    slen = sp[1]
    batch_size = sp[0]
    total_num = (slen-1)//frame_step
    padsignal = np.concatenate((signals, np.zeros((batch_size, total_num*frame_step+frame_len-slen) )  ) ,axis=1)
    shape = padsignal.shape[:-1]+(total_num+1 , frame_len)  # [num of signal, num of frame, frame length]
    win = winfunc(total_num+1, frame_len)
    strides = (padsignal.strides[0],) + (padsignal.strides[-1]*frame_step,) + (padsignal.strides[-1],)
    frames = np.lib.stride_tricks.as_strided(padsignal, shape=shape, strides=strides)
    return frames * win



# energy in high frequency range is low, so increase them first
def preemphasis(signal, coeff=0.95):
    return np.append(signal[:,0].reshape(-1,1) , signal[:,1:] - coeff * signal[:,:-1] , axis=1)

# power spectrum   512 point fft
def powspec(frames, NFFT=512):
    return 1.0 / NFFT * np.square(magspec(frames, NFFT))
# fft magnitude
def magspec(frames, NFFT=512):
    complex_spec = np.fft.rfft(frames, n=NFFT, axis=-1)
    return np.absolute(complex_spec)

# filter bank  fb=2 dims  [num of filter, 257=nfft/2+1]

def get_fb(num=26, lowfreq=300, highfreq=8000, fs=16000, nfft=512):
    lowmel = hz2mel(lowfreq)
    highmel = hz2mel(highfreq)
    melfb = np.linspace(lowmel, highmel, num+2)
    hzfb = mel2hz(melfb)
    bin = np.floor( (nfft+1)*hzfb/fs  ).astype(int)
    fb = np.zeros( (num, nfft//2+1 ) )
    for i in range(0, num):
        for j in range(bin[i], bin[i+1]):
            fb[i][j] = (j-bin[i])/(bin[i+1]-bin[i])
        for j in range(bin[i+1], bin[i+2]):
            fb[i][j] = (bin[i+2]-j)/(bin[i+2]-bin[i])
    return fb


# conver hz to mel, vice versa
def mel2hz(f_mel):
    return 700 * (10 ** (f_mel / 2595.0) - 1)

def hz2mel(f_hz):
    return 2595 * np.log10(1+f_hz/700.)

# improve the recog effect in noisy env
def lifter(cepstra, L=22):
    """Apply a cepstral lifter the the matrix of cepstra. This has the effect of increasing the
    magnitude of the high frequency DCT coeffs.
    :param cepstra: the matrix of mel-cepstra, will be numframes * numcep in size.
    :param L: the liftering coefficient to use. Default is 22. L <= 0 disables lifter.
    """
    if L > 0:
        _,nframes,ncoeff = np.shape(cepstra)
        n = np.arange(ncoeff)
        lift = 1 + (L/2.)*np.sin(np.pi*n/L)
        return cepstra*lift
    else:
        # values of L <= 0, do nothing
        return cepstra


def get_label_from_txt(label_dim,label_cat,file_path):
    fp = open(file_path)
    cnt=0.
    cat=np.zeros((9))
    dim=np.zeros((3))
    last = ''
    for line in fp:
        if line[0]=='C':
            cnt+=1.
            if 'Sadness' in line:
                cat[0]+=1.
            if 'Fear' in line:
                cat[1]+=1.
            if 'Neutral' in line:
                cat[2]+=1.
            if 'Frustration' in line:
                cat[3]+=1.
            if 'Anger' in line:
                cat[4]+=1.
            if 'Surprise' in line:
                cat[5]+=1.
            if 'Disgust' in line:
                cat[6]+=1.
            if 'Happiness' in line:
                cat[7]+=1.
            if 'Excited' in line:
                cat[8]+=1.

        elif line[0]=='[' :
            cnt=0.
            cat=np.zeros((9))
            dim=np.zeros((3))
            dim[0]=float(line[-24:-18])
            dim[1]=float(line[-16:-10])
            dim[2]=float(line[-8:-2])
            label_dim.append(dim)
        elif line[0]=='A'and last=='C':
            cat=cat/cnt
            #print(cat)
            label_cat.append(cat)
        last=line[0]
    return

def get_label_from_EmoEval(label_dim,label_cat,file_path):
    lst = os.listdir(file_path)
    for file in lst:
        if file[-3:] !='txt':
            pass
        else:
            path = os.path.join(file_path,file)
            get_label_from_txt(label_dim,label_cat,path)
    return

# step of mfcc:
# a.preprocessing: 1.sampling=>frames  2.preemphasis  3.filter
# b. 1.fft  2.melbank  3.



def mfccs(signals, fs=16000, len_sec=25, step_sec=10, nfb=26, nfft=512, numcep=13, ceplifter=22, appendEnergy=True):
    frame_len = int(len_sec * fs / 1000)
    frame_step = int(step_sec * fs / 1000)
    signal = preemphasis(signals, 0.95)

    def winfunc(num, frame_len):
        win = np.arange(frame_len)
        win = 0.54 - 0.46 * np.cos(2 * np.pi * win / (frame_len - 1))
        ret = np.ones((num, frame_len))
        return ret * win

    frames = frames_sig(signal, frame_len, frame_step, winfunc)  # 3 dims
    fb = get_fb(num=26, lowfreq=300, highfreq=8000, fs=16000, nfft=512)
    power_spec = powspec(frames, nfft)
    energy = np.sum(power_spec, axis=-1)
    energy = np.where(energy == 0, np.finfo(float).eps, energy)
    feat = np.dot(power_spec[:, :], fb.T)
    feat = np.where(feat == 0, np.finfo(float).eps, feat)

    feat = np.log(feat)
    feat = dct(feat, type=2, axis=-1, norm='ortho')[:, :, :numcep]
    feat = lifter(feat, ceplifter)
    if appendEnergy:
        feat[:, :, 0] = np.log(energy)
    return feat   # [batch_size, num_frame, 13]  随信号长度改变而变化

def mfcc(signals, fs=16000, len_sec=25, step_sec=10, nfb=26, nfft=512, numcep=13, ceplifter=22, appendEnergy=True):
    frame_len = int(len_sec * fs / 1000)
    frame_step = int(step_sec * fs / 1000)
    signal = preemphasis(signals, 0.95)

    def winfunc(num, frame_len):
        win = np.arange(frame_len)
        win = 0.54 - 0.46 * np.cos(2 * np.pi * win / (frame_len - 1))
        ret = np.ones((num, frame_len))
        return ret * win

    frames = frames_sig(signal, frame_len, frame_step, winfunc)  # 3 dims
    fb = get_fb(num=26, lowfreq=300, highfreq=8000, fs=16000, nfft=512)
    power_spec = powspec(frames, nfft)
    energy = np.sum(power_spec, axis=-1)
    energy = np.where(energy == 0, np.finfo(float).eps, energy)
    feat = np.dot(power_spec[:, :], fb.T)
    feat = np.where(feat == 0, np.finfo(float).eps, feat)

    feat = np.log(feat)
    feat = dct(feat, type=2, axis=-1, norm='ortho')[:, :, :numcep]
    feat = lifter(feat, ceplifter)
    if appendEnergy:
        feat[:, :, 0] = np.log(energy)
    return feat  #[ num_frame, 13 ]  随信号长度改变而变化

# append signal to signals
def get_signal(signals,fp, fs=16000):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    wav_file_path = fp
    orig_wav_files = os.listdir(wav_file_path)
    for orig_wav_file in tqdm(orig_wav_files):
        for wav in os.listdir(os.path.join(wav_file_path,orig_wav_file)):
            if wav[-3:]!='wav':
                pass
            else:
                signal, sr = librosa.load(os.path.join(wav_file_path,orig_wav_file,wav), fs)
                signals.append( torch.tensor( mfcc(signal[None,])[0] ).type(torch.float32).to(device) )
    return

