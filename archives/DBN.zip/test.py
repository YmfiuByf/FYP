import torch
from torch.nn.utils.rnn import pack_sequence, pad_sequence, pack_padded_sequence, pad_packed_sequence
from torch.nn import LSTM
from preprocessing import *
from sklearn.model_selection import train_test_split

def eval(model, loss_function, X_val, y_val, batch_size):
    model.eval()
    num=0
    total_loss=0
    for b in range(len(X_val) // batch_size):
        # print(seq.size(),labels.size())
        batch_X = X_val[b * batch_size:b * batch_size + batch_size]
        labels = y_val[b * batch_size:b * batch_size + batch_size]
        batch_X = pack_sequence(batch_X, enforce_sorted=False)
        # print(batch_X[0],batch_X[1],len(batch_X))
        model.hidden_cell = (torch.zeros(1, batch_size, model.hidden_layer_size).to(device),
                             torch.zeros(1, batch_size, model.hidden_layer_size).to(device))

        y_pred = model(batch_X)

        single_loss = loss_function(y_pred, labels)  # 损失函数
        total_loss += single_loss
        num=b+1
        if b%100==0:
            print(single_loss)
    return total_loss/num

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#os.environ['CUDA_VISIBLE_DEVICES'] = '1'
signals=[]
get_signal(signals,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session1\\sentences\\wav')
get_signal(signals,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session2\\sentences\\wav')
get_signal(signals,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session3\\sentences\\wav')
get_signal(signals,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session4\\sentences\\wav')
get_signal(signals,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session5\\sentences\\wav')
print(len(signals))
print(signals[0].size(),signals[1].size())

label_dim,label_cat=[],[]
get_label_from_EmoEval(label_dim,label_cat,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session1\\dialog\\EmoEvaluation')
get_label_from_EmoEval(label_dim,label_cat,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session2\\dialog\\EmoEvaluation')
get_label_from_EmoEval(label_dim,label_cat,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session3\\dialog\\EmoEvaluation')
get_label_from_EmoEval(label_dim,label_cat,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session4\\dialog\\EmoEvaluation')
get_label_from_EmoEval(label_dim,label_cat,'D:\\pycharmProject\\FYP\\IEMOCAP语料库\\Session5\\dialog\\EmoEvaluation')

X, X_test, y, y_test = train_test_split(signals, label_cat, test_size=0.1,random_state=0)
X_train, X_val,y_train, y_val = train_test_split(X,y,test_size=0.2,random_state=0)
y_train = torch.tensor(y_train).to(device)

model = torch.load('D:\\pycharmProject\\FYP\\LSTM2.dat')

for i in range(20):
    print(f'{i}: true={y_test[i]}, pred={model(X_test[i][None,:,:])}')
