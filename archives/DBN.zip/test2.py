import torch
import transformers


model = torch.load("E:\\Edge download\\w2v_large_lv_fsh_swbd_cv_ftls960_updated.pt")

